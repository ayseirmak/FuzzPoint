/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = ((16020));
	float f = a + ((30262));

	return f == a;
}
/* ProgramSourceWild */
