/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (12385);
	float f = a + (2471);

	return f == a;
}
/* ProgramSourceWild */
