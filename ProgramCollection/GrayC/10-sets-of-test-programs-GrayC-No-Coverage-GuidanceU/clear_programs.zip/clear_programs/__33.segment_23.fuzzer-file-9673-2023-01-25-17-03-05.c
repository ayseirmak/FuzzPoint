/* corpus/00119.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
double x = (((7313)));

int
main()
{
	return x < (((6526)));
}
/* ProgramSourceWild */
