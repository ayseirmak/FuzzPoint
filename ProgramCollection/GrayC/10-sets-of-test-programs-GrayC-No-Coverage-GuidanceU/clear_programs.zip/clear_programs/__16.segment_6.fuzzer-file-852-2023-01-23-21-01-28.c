/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (8425);
	float f = a + (32730);

	return f == a;
}
/* ProgramSourceWild */
