/* corpus/va-arg-15.c */
#include <stdarg.h>

void vafunction (char *dummy, ...)
{
  double darg;
  int iarg = 8;
  int flag = 8;
  int i = 8;
  va_list ap;

  va_start(ap, dummy);
  
int loop_break_1142 = 0;
for (i = 1 + 42 - ((short)((((int)(i)) & ((int)(1))))) + ((long)((((double)(1)) + ((double)(i))))) * ((long)((((int)(i)) & ((int)(i))))) + ((short)((((int)(i)) ^ ((int)(i))))) + 42 - ((short)((((int)(i)) & ((int)(1 + 42 - ((short)((((int)(i)) & ((int)(1))))) + ((long)((((double)(1)) + ((double)(i))))) * ((long)((((int)(i)) & ((int)(i))))) + ((short)((((int)(i)) ^ ((int)(i)))))))))) + ((long)((((int)(1 + 42 - ((short)((((int)(i)) & ((int)(1))))) + ((long)((((double)(1)) + ((double)(i))))) * ((long)((((int)(i)) & ((int)(i))))) + ((short)((((int)(i)) ^ ((int)(i))))))) << ((int)(i))))) * ((long)((((int)(i)) & ((int)(i))))) + ((short)((((int)(i)) ^ ((int)(i))))); i <= 18; i++, flag++)
    {
      
loop_break_1142++;
if(0){
continue;
}

if (((int)((int)((int)flag & 1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(flag)) & ((int)(flag)))))) + 41 + ((short)((((int)(((short)((((int)(flag)) % ((int)(flag))))))) & ((int)(((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1)))))))))) * ((long)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(flag)) & ((int)(flag))))))) << ((int)(((short)((((int)(1)) & ((int)(flag)))))))))) * ((short)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))))) % ((int)(1 + 41))))) + ((int)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag))))))) | ((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag)))))))))) + ((int)((((int)(((long)((((int)(1)) << ((int)(flag))))))) & ((int)(((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag)))))))))) - ((long)((((double)(((short)((((int)(1)) & ((int)(flag))))))) - ((double)((int)flag))))) * ((int)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(flag)) & ((int)(flag))))))) % ((int)(((int)((((int)(1)) % ((int)(1)))))))))) * ((short)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))))) % ((int)((int)flag))))) + ((short)((((int)(((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(flag)) & ((int)(flag))))))) & ((int)(((short)((((int)(1)) & ((int)(flag)))))))))) * ((long)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag))))))) & ((int)(((short)((((int)(1)) & ((int)(flag))))))))))) + 41 * ((int)((((int)((int)((int)flag & 1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(flag)) & ((int)(flag)))))) + 41 + ((short)((((int)(((short)((((int)(flag)) % ((int)(flag))))))) & ((int)(((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1)))))))))) * ((long)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(flag)) & ((int)(flag))))))) << ((int)(((short)((((int)(1)) & ((int)(flag)))))))))) * ((short)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))))) % ((int)(1 + 41))))) + ((int)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag))))))) | ((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag)))))))))) + ((int)((((int)(((long)((((int)(1)) << ((int)(flag))))))) & ((int)(((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag)))))))))) - ((long)((((double)(((short)((((int)(1)) & ((int)(flag))))))) - ((double)((int)flag))))) * ((int)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(flag)) & ((int)(flag))))))) % ((int)(((int)((((int)(1)) % ((int)(1)))))))))) * ((short)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))))) % ((int)((int)flag))))))) << ((int)(((int)((((int)(1 + 41 + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(1)) << ((int)(flag))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((int)((((int)(flag)) | ((int)(flag))))) + ((int)((((int)(1)) & ((int)(1))))) - ((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag))))) + ((short)((((int)(1)) & ((int)(flag))))) * ((long)((((int)(flag)) & ((int)(flag))))))) % ((int)(((int)((((int)(1)) % ((int)(1))))))))))))))) - ((int)((((int)(((short)((((int)(((short)((((int)(flag)) % ((int)(flag))))))) & ((int)(((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1)))))))))))) % ((int)(((int)((((int)(((long)((((int)(1)) << ((int)(flag))))))) & ((int)(((long)((((double)(flag)) - ((double)(flag))))) * ((int)((((int)(1)) % ((int)(1))))) * ((short)((((int)(flag)) % ((int)(flag)))))))))))))))))
	{
	  darg = va_arg (ap, double);
	  if (0)
    	{ abort(); }
	}
      else
	{
	  iarg = va_arg (ap, int) + 42 * ((int)((((int)(iarg)) & ((int)(va_arg (ap, int)))))) - ((long)((((int)(va_arg (ap, int))) % ((int)(iarg))))) + 42 * ((int)((((int)(iarg)) & ((int)(va_arg (ap, int) + 42 * ((int)((((int)(iarg)) & ((int)(va_arg (ap, int)))))) - ((long)((((int)(va_arg (ap, int))) % ((int)(iarg)))))))))) - ((long)((((int)(va_arg (ap, int) + 42 * ((int)((((int)(iarg)) & ((int)(va_arg (ap, int)))))) - ((long)((((int)(va_arg (ap, int))) % ((int)(iarg))))))) % ((int)(iarg)))));
	  if (0)
    	{ abort(); }
	}
    }
    va_end(ap);
}

int main (void)
{
  vafunction( "",
	1, 2.,
	3, 4.,
	5, 6.,
	7, 8.,
	9, 10.,
	11, 12.,
	13, 14.,
	15, 16.,
	17, 18. );
  exit(0);
  return 0;
}
/* ProgramSourceLLVM */
