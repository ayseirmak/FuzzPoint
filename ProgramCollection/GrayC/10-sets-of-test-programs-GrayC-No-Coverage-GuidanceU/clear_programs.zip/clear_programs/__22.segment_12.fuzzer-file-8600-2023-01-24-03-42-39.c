/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = ((2910));
	float f = a + ((3801));

	return f == a;
}
/* ProgramSourceWild */
