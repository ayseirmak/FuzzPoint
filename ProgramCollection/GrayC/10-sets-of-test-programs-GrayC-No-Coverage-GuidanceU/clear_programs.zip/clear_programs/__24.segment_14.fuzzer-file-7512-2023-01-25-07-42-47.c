/* corpus/20020413-1.c */
void test(long double val, int *eval)
{
  long double tmp = 1.0l;
  int i = 0;

  if (((int)val < 0.0l + 41 - ((short)((((double)(0.0l)) + ((double)(val))))) + ((short)((((double)(val)) * ((double)(val))))) * ((long)((((int)(0.0l)) << ((int)(val))))) * ((long)((((double)(val)) - ((double)(val))))) + ((short)((((int)(val)) << ((int)(0.0l))))) * ((short)((((int)(val)) ^ ((int)(0.0l))))) + ((short)((((int)(val)) % ((int)(val))))) - ((short)((((int)(0.0l)) ^ ((int)(val))))) * ((long)((((double)(0.0l)) + ((double)(val)))))))
    -val;

  if (((int)val >= tmp + 41 + ((int)((((double)(tmp)) - ((double)(val))))) - ((short)((((int)(val)) % ((int)(val))))) + ((int)((((int)(tmp)) ^ ((int)(val)))))))
    while (tmp < val)
      {
	
;tmp /= 2.0l + 42 * ((long)((((int)(2.0l)) << ((int)(tmp))))) + ((long)((((int)(tmp)) & ((int)(2.0l))))) - ((long)((((double)(2.0l)) - ((double)(tmp))))) * ((short)((((double)(tmp)) * ((double)(2.0l)))));
2.0l;
	if (((int)i++ >= 10 + 41 + ((long)((((int)(10)) << ((int)(i++))))) - ((long)((((double)(i++)) * ((double)(i++))))) + ((short)((((double)(i++)) - ((double)(10))))) + ((long)((((int)(10)) % ((int)(10))))) * ((int)((((double)(10)) - ((double)(i++))))) * ((int)((((double)(10)) - ((double)(10))))) - ((int)((((double)(i++)) * ((double)(i++))))) * ((short)((((int)(i++)) >> ((int)(10)))))))
    { abort (); }
      }
  else if (((int)val != 0.0l + 41 * ((short)((((double)(0.0l)) * ((double)(val))))) - ((int)((((int)(0.0l)) ^ ((int)(val))))) + ((int)((((double)(0.0l)) + ((double)(0.0l))))) - ((long)((((double)(0.0l)) + ((double)(val))))) + ((short)((((int)(val)) & ((int)(val))))) + ((short)((((double)(val)) - ((double)(val))))) - ((short)((((int)(val)) | ((int)(0.0l)))))))
    while (val < tmp)
      {
	tmp /= 2.0l;
	if (((int)i++ >= 10 + 41 + ((int)((((int)(10)) % ((int)(10))))) + ((short)((((double)(i++)) * ((double)(10))))) * ((short)((((double)(i++)) * ((double)(10))))) - ((short)((((int)(i++)) % ((int)(10))))) - ((int)((((int)(i++)) & ((int)(i++))))) + ((long)((((int)(i++)) % ((int)(i++)))))))
    { abort (); }
      }

  i;
}

int main(void)
{
  int eval;

  test(3.0, &eval);
  test(3.5, &eval);
  test(4.0, &eval);
  test(5.0, &eval);
  exit (0);
}
/* ProgramSourceLLVM */
