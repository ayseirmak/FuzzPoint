/* corpus/00119.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
double x = (16220);

int
main()
{
	return x < (13693);
}
/* ProgramSourceWild */
