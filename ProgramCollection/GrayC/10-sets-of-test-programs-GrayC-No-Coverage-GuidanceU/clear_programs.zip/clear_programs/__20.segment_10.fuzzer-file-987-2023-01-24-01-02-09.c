/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (16358);
	float f = a + (5804);

	return f == a;
}
/* ProgramSourceWild */
