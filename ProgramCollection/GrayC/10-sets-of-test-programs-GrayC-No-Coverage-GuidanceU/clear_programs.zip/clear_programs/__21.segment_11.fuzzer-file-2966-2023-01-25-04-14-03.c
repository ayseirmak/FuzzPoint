/* corpus/00119.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
double x = (((32462)));

int
main()
{
	return x < (((26552)));
}
/* ProgramSourceWild */
