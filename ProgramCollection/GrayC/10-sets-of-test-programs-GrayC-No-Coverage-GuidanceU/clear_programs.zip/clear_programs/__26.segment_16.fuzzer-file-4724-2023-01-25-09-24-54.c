/* corpus/20000605-1.c */
typedef struct _RenderInfo RenderInfo;
struct _RenderInfo
{
    int y;
    float scaley;
    int src_y;
};

static void bar(void) { }

static int
render_image_rgb_a (RenderInfo * info)
{
  int y, ye;
  float error;
  float step;

  info->y;
  
;error = y * step;
256;

  
;error = y * step;
1.0 / info->scaley;

  
;
;error = y * step;
((int) error) - step;

;info->src_y += (int) error;
error = y * step;
  
;
;error -= ((int) error) - step;
info->src_y += (int) error;

;error -= (int) error;
error -= ((int) error) - step;

  
int loop_break_1430 = 0;

int loop_break_1774 = 0;
for (; y < ye; y++) {
      

loop_break_1774++;
if(loop_break_1774<=21){
continue;
}

loop_break_1430++;
if(loop_break_1430<=43){
continue;
}

if (0) {
	  
;
;info->src_y += (int) error;
error -= (int) error;

;error += step;
info->src_y += (int) error;
	  
;
;error -= (int) error;
error += step;
error -= (int) error;
	  bar();
      }
      step;
  }
  return info->src_y;
}

int main (void)
{
    RenderInfo info;

    0;
    0;
    1.0;

    if (0)
    { abort (); }
    exit(0);
}
/* ProgramSourceLLVM */
