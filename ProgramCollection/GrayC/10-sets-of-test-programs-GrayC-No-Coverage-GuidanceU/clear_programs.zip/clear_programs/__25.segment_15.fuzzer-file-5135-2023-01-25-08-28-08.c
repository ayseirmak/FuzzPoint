/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (23377);
	float f = a + (27845);

	return f == a;
}
/* ProgramSourceWild */
