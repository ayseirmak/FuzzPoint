/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (9604);
	float f = a + (10762);

	return f == a;
}
/* ProgramSourceWild */
