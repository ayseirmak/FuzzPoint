/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (15241);
	float f = a + (1373);

	return f == a;
}
/* ProgramSourceWild */
