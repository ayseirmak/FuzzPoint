/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = ((11631));
	float f = a + ((2802));

	return f == a;
}
/* ProgramSourceWild */
