/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = ((24977));
	float f = a + (((18043)));

	return f == a;
}
/* ProgramSourceWild */
