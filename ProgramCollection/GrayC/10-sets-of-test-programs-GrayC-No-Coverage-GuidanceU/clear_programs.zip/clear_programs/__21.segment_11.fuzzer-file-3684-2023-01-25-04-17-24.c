/* corpus/00119.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
double x = ((14643));

int
main()
{
	return x < ((10248));
}
/* ProgramSourceWild */
