/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (21229);
	float f = a + (27937);

	return f == a;
}
/* ProgramSourceWild */
