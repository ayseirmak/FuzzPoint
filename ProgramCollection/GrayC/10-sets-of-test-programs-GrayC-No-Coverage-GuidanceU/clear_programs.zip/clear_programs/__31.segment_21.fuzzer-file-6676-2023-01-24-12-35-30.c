/* corpus/00119.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
double x = (17786);

int
main()
{
	return x < (2717);
}
/* ProgramSourceWild */
