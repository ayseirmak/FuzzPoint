/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = ((8551));
	float f = a + ((11305));

	return f == a;
}
/* ProgramSourceWild */
