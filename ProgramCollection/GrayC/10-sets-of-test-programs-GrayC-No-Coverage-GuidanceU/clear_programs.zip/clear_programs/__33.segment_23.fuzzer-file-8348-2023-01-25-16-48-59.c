/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (5655);
	float f = a + (7679);

	return f == a;
}
/* ProgramSourceWild */
