/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (((((8600)))));
	float f = a + (((((19303)))));

	return f == a;
}
/* ProgramSourceWild */
