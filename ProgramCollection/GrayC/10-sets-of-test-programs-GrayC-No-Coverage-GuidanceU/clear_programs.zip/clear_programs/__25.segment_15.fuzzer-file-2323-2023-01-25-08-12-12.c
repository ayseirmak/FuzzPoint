/* corpus/20000605-1.c */
typedef struct _RenderInfo RenderInfo;
struct _RenderInfo
{
    int y;
    float scaley;
    int src_y;
};

static void bar(void) { }

static int
render_image_rgb_a (RenderInfo * info)
{
  int y, ye;
  float error;
  float step;

  
;ye = 256;
info->y;
  
;step = 1.0 / info->scaley;
ye = 256;

  step;

  
;((int) error) - step;
y * step;
  ((int) error) - step;

  
int loop_break_1260 = 8;

int loop_break_1326 = 0;
for (; y < ye; y++) {
      

loop_break_1326++;
if(0){
continue;
}

loop_break_1260++;
if(0){
break;
}

if (0) {
	  (int) error;
	  (int) error;
	  bar();
      }
      
;0;
step;
  }
  return info->src_y;
}

int main (void)
{
    RenderInfo info;

    
;info.scaley = 1.0;
0;
    
;
;info.scaley = 1.0;
info.scaley = 1.0;
0;
    info.scaley = 1.0;

    if (0)
    { abort (); }
    exit(0);
}
/* ProgramSourceLLVM */
