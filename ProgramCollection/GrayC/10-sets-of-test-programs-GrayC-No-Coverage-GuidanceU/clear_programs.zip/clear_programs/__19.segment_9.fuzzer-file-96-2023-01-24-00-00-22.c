/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (23366);
	float f = a + (7814);

	return f == a;
}
/* ProgramSourceWild */
