/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (((1585)));
	float f = a + (((25388)));

	return f == a;
}
/* ProgramSourceWild */
