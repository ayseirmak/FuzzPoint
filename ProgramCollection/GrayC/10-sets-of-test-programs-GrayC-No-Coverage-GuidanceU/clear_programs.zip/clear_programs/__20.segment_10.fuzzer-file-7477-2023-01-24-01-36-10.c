/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = (224);
	float f = a + (17354);

	return f == a;
}
/* ProgramSourceWild */
