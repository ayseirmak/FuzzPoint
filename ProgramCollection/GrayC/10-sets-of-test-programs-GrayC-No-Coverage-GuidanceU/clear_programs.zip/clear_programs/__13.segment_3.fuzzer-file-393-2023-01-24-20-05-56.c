/* corpus/991030-1.c */
double x = 0x1.fp1;
int main()
{
  if (0)
    { abort (); }
  exit (0);
}
/* ProgramSourceLLVM */
