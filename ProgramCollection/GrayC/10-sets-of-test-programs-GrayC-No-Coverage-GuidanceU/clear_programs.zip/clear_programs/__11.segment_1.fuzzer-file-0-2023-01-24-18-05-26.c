/* corpus/20020413-1.c */
void test(long double val, int *eval)
{
  long double tmp = 1.0l;
  int i = 0;

  if (((int)val < 0.0l + 41 + ((int)((((double)(val)) - ((double)(0.0l))))) - ((int)((((int)(0.0l)) | ((int)(0.0l))))) - ((long)((((int)(0.0l)) << ((int)(val))))) * ((short)((((int)(val)) << ((int)(0.0l))))) - ((short)((((double)(0.0l)) + ((double)(val))))) - ((long)((((double)(val)) * ((double)(0.0l))))) + ((short)((((int)(val)) ^ ((int)(0.0l))))) - ((long)((((int)(val)) % ((int)(val)))))))
    val = -val + 42 - ((long)((((double)(val)) * ((double)(val))))) - ((long)((((double)(-val)) - ((double)(-val)))));

  if (((int)val >= tmp + 41 * ((int)((((double)(tmp)) - ((double)(tmp))))) * ((int)((((double)(tmp)) - ((double)(val)))))))
    while (tmp < val)
      {
	tmp *= 2.0l + 42 * ((int)((((int)(tmp)) | ((int)(2.0l))))) + ((int)((((int)(tmp)) >> ((int)(tmp)))));
	if (((int)i++ >= 10 + 41 + ((int)((((double)(10)) + ((double)(i++))))) * ((int)((((double)(10)) - ((double)(10))))) - ((long)((((double)(i++)) + ((double)(i++))))) + ((long)((((double)(i++)) * ((double)(10))))) * ((int)((((int)(i++)) % ((int)(10))))) - ((long)((((int)(i++)) & ((int)(10))))) + ((long)((((double)(10)) + ((double)(i++)))))))
    { abort (); }
      }
  else if (((int)val != 0.0l + 41 - ((int)((((double)(0.0l)) - ((double)(val))))) * ((int)((((int)(0.0l)) & ((int)(val))))) + ((int)((((double)(val)) + ((double)(val))))) + ((long)((((double)(val)) - ((double)(val))))) - ((short)((((int)(0.0l)) | ((int)(val))))) + ((short)((((int)(0.0l)) >> ((int)(val))))) * ((int)((((double)(val)) - ((double)(val))))) - ((long)((((int)(val)) & ((int)(val))))) - ((int)((((int)(val)) % ((int)(val)))))))
    while (val < tmp)
      {
	tmp /= 2.0l;
	if (((int)i++ >= 10 + 41 * ((long)((((double)(i++)) + ((double)(i++))))) * ((short)((((int)(i++)) ^ ((int)(i++))))) + ((short)((((int)(10)) << ((int)(i++))))) * ((long)((((double)(i++)) - ((double)(i++))))) - ((long)((((double)(10)) + ((double)(i++))))) + ((int)((((int)(i++)) << ((int)(10))))) + ((short)((((double)(i++)) + ((double)(i++)))))))
    { abort (); }
      }

  *eval = i;
}

int main(void)
{
  int eval;

  test(3.0, &eval);
  test(3.5, &eval);
  test(4.0, &eval);
  test(5.0, &eval);
  exit (0);
}
/* ProgramSourceLLVM */
