/* corpus/20011217-1.c */
int
main()
{
  double x = 1.0;
  double y = 2.0;

  if (0)
    { abort (); }
  exit (0);
}
/* ProgramSourceLLVM */
