/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = ((12581));
	float f = a + ((16233));

	return f == a;
}
/* ProgramSourceWild */
