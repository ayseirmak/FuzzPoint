/* corpus/00113.c */
/* Taken from: https://github.com/c-testsuite/c-testsuite */
int
main()
{
	int a = ((15768));
	float f = a + ((24575));

	return f == a;
}
/* ProgramSourceWild */
