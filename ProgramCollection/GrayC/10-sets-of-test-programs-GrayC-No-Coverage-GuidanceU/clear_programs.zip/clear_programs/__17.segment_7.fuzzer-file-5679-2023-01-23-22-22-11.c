/* corpus/va-arg-15.c */
#include <stdarg.h>

void vafunction (char *dummy, ...)
{
  double darg;
  int iarg = 8;
  int flag = 8;
  int i = 8;
  va_list ap;

  va_start(ap, dummy);
  
int loop_break_2716 = 0;

int loop_break_1780 = 8;

int loop_break_1834 = 0;

int loop_break_1896 = 0;

int loop_break_2862 = 0;
for (i = 1; i <= 18; i++, flag++)
    {
      




loop_break_2862++;
if(((int)loop_break_2862<=38 + 41 + ((short)((((double)(loop_break_2862)) * ((double)(38))))))){
break;
}

loop_break_1896++;
if(((int)((int)loop_break_1896<=38 + 41 * ((short)((((int)(38)) % ((int)(38))))) + ((int)((((int)(38)) ^ ((int)(38))))) + ((int)((((double)(38)) * ((double)(38)))))) + 41 + ((int)((((int)(38 + 41 * ((short)((((int)(38)) % ((int)(38))))))) % ((int)(((int)((((double)(38)) * ((double)(38)))))))))) - ((short)((((int)(38 + 41 * ((short)((((int)(38)) % ((int)(38))))) + ((int)((((int)(38)) ^ ((int)(38))))))) >> ((int)(38 + 41 * ((short)((((int)(38)) % ((int)(38))))) + ((int)((((int)(38)) ^ ((int)(38))))) + ((int)((((double)(38)) * ((double)(38)))))))))))){
break;
}

loop_break_1834++;
if(((int)((int)loop_break_1834<=28 + 41 + ((int)((((double)(28)) + ((double)(loop_break_1834))))) * ((long)((((double)(loop_break_1834)) * ((double)(28))))) + ((int)((((double)(28)) - ((double)(loop_break_1834))))) + ((int)((((double)(loop_break_1834)) + ((double)(28)))))) + 41 * ((long)((((int)(((long)((((double)(loop_break_1834)) * ((double)(28))))))) >> ((int)(((int)((((double)(28)) + ((double)(loop_break_1834))))) * ((long)((((double)(loop_break_1834)) * ((double)(28)))))))))) - ((long)((((int)(28 + 41)) >> ((int)(((int)((((double)(28)) + ((double)(loop_break_1834))))) * ((long)((((double)(loop_break_1834)) * ((double)(28)))))))))) * ((int)((((int)(28 + 41 + ((int)((((double)(28)) + ((double)(loop_break_1834))))) * ((long)((((double)(loop_break_1834)) * ((double)(28))))))) | ((int)(((int)((((double)(28)) + ((double)(loop_break_1834))))) * ((long)((((double)(loop_break_1834)) * ((double)(28)))))))))) * ((int)((((double)((int)loop_break_1834)) * ((double)((int)loop_break_1834))))) - ((int)((((int)(28 + 41 + ((int)((((double)(28)) + ((double)(loop_break_1834))))) * ((long)((((double)(loop_break_1834)) * ((double)(28))))))) >> ((int)(((int)((((double)(loop_break_1834)) + ((double)(28)))))))))) + ((short)((((int)(((int)((((double)(28)) + ((double)(loop_break_1834))))) * ((long)((((double)(loop_break_1834)) * ((double)(28))))))) & ((int)(((int)((((double)(loop_break_1834)) + ((double)(28)))))))))) - ((short)((((int)(28 + 41 + ((int)((((double)(28)) + ((double)(loop_break_1834))))) * ((long)((((double)(loop_break_1834)) * ((double)(28))))))) & ((int)(((int)((((double)(28)) + ((double)(loop_break_1834)))))))))) - ((short)((((double)(((int)((((double)(28)) - ((double)(loop_break_1834))))))) + ((double)(((int)((((double)(loop_break_1834)) + ((double)(28)))))))))))){
continue;
}

loop_break_1780++;
if(((int)((int)loop_break_1780<=49 + 41 * ((short)((((double)(49)) * ((double)(49)))))) + 41 - ((long)((((int)(41)) >> ((int)(((short)((((double)(49)) * ((double)(49)))))))))) + ((long)((((int)(49 + 41 * ((short)((((double)(49)) * ((double)(49))))))) & ((int)(41 * ((short)((((double)(49)) * ((double)(49)))))))))) + ((int)((((int)(41 * ((short)((((double)(49)) * ((double)(49))))))) >> ((int)(49))))) * ((short)((((int)(49 + 41 * ((short)((((double)(49)) * ((double)(49))))))) % ((int)(49 + 41 * ((short)((((double)(49)) * ((double)(49)))))))))) - ((long)((((int)(41)) & ((int)(49 + 41 * ((short)((((double)(49)) * ((double)(49)))))))))) - ((short)((((int)(49)) | ((int)(((short)((((double)(49)) * ((double)(49)))))))))) + ((int)((((double)((int)loop_break_1780)) * ((double)((int)loop_break_1780))))) + ((int)((((int)(41 * ((short)((((double)(49)) * ((double)(49))))))) & ((int)(((short)((((double)(49)) * ((double)(49)))))))))))){
continue;
}

loop_break_2716++;
if(0){
continue;
}

if (0)
	{
	  va_arg (ap, double) + 42 - ((long)((((double)(darg)) - ((double)(darg))))) + ((int)((((int)(va_arg (ap, double))) & ((int)(darg))))) * ((long)((((double)(darg)) - ((double)(darg))))) - ((long)((((int)(va_arg (ap, double))) | ((int)(darg)))));
	  if (0)
    	{ abort(); }
	}
      else
	{
	  va_arg (ap, int) + 42 * ((long)((((int)(va_arg (ap, int))) & ((int)(iarg)))));
	  if (0)
    	{ abort(); }
	}
    }
    va_end(ap);
}

int main (void)
{
  vafunction( "",
	1, 2.,
	3, 4.,
	5, 6.,
	7, 8.,
	9, 10.,
	11, 12.,
	13, 14.,
	15, 16.,
	17, 18. );
  exit(0);
  return 0;
}
/* ProgramSourceLLVM */
